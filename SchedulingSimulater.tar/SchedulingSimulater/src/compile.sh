gcc process_queue.c scheduling.c main.c
#./a.out

